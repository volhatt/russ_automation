'''
Created on Oct 19, 2016


@author: sashaalexander
@author: team X
'''
from rfaUtils import getLog,qaPrint,getLocalEnv, getCleanString

import sys

#get cmd arguments
#argv = sys.argv
argv = ["rfaRunner.py", "--testrun=42"]

#def usage - check on format 
if len(argv) != 2:
    print("something wrong here ")
    sys.exit('the arguments should be like \"--testrun=[0-10000]\"')
    
file_name = getCleanString(argv[0])
#print("File Name Is : ", file_name)

trid = int(getCleanString((argv[1].split('='))[1]))
print("this is trid : ", trid)

#get local variables as dictionary
localEnv = getLocalEnv('local.properties')
# check, delete later
for i in localEnv:
    print i + ' : ' + localEnv[i]
    
if localEnv == -1:
    sys.exit("Unable to get property file")

# take  local dir from properties file 
log_dir = getCleanString(localEnv['log_dir'])
if log_dir == '':
    #print"No value in log_dir"
    sys.exit("No value in log_dir")

# taking arguments/


def usage():
    #invalid parameters from cmd
    print "Invalid parameters. Proper usage: (example)"
    pass

# get the log file handle
log = getLog(file_name, log_dir)

# exit if log creation failed
if log == -1:
    sys.exit("Unable to create log file")

message = "It is working, right?"

# call qaPrint to print a message with timestamp and write it to the log file
qaPrint(log, message)
qaPrint(log, "Me like what me see")

# close the log file if it open
if not log.closed:
    log.close()



